<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

if (file_exists('/home/unfami5/public_html/notinsomanywords.com/wp-content/plugins/wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", '/home/unfami5/public_html/notinsomanywords.com/wp-content/wflogs/');
	include_once '/home/unfami5/public_html/notinsomanywords.com/wp-content/plugins/wordfence/waf/bootstrap.php';
}
?>