<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'unfami5_notinsomanywords' );

/** MySQL database username */
define( 'DB_USER', 'unfami5_notinsomanywords' );

/** MySQL database password */
define( 'DB_PASSWORD', 'k(+FfJ#f!W+L' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Vl6*zqQS,0z6cOvWbM,~xAa|9}9>F!lXG9HW09PMv^VKroc&k}Db2d7P7t&zUB3l' );
define( 'SECURE_AUTH_KEY',  'PZ!u3-_iYE{NG_h|#T7XYp;K+87w)&-Y*tk-0E}]2>iL@/ I`EWg!A|szz2^O-C$' );
define( 'LOGGED_IN_KEY',    '{5tST0)tyluBb_du1m!2eO5A!Lha3>D3+2!{nv+Uri!C;}dH5[oQi=3pKP.<A/)G' );
define( 'NONCE_KEY',        'JS+{6XSE&R6twP;)InHVnen6)_,k]J[2cmI0462SFAmM2hc;#B/u_;-%KWBE]}tU' );
define( 'AUTH_SALT',        'XyEYy3hw<d|.IKe`Ee4TYyn8b5k1LolNgH>xKL6j$cI$K.GU -NEX0>.UYNuc#jn' );
define( 'SECURE_AUTH_SALT', 'T)KkrOa;g%:fLcNJ<gC8VlwLr_`0#i]A<J-npmgB^C66p*Rd6Y97qK>9V];&LQy7' );
define( 'LOGGED_IN_SALT',   'Fs*)rJuCE$1ib*IW&:(a5XI2Hv4]# %2~7Rql,O#_Q^1g:WBMA,dbi{Z5xd}jcm0' );
define( 'NONCE_SALT',       '3FYY,C2N2 c@v8CEvgn)W@J!$#4/y$8!SokW?PQZ7[bq<[,+jogT&ctxVfeGvY]q' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
